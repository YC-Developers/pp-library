const express = require('express');
const pool = require('../config/db');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const router = express.Router();

router.get('/', async (req, res) => {
    try {
        const [books] = await pool.query('SELECT * FROM Books');
        res.json(books);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
});

router.post('/', requireAuth, requireAdmin, async (req, res) => {
    const { title, author, isbn, category, quantity } = req.body;
    try {
        await pool.query(
            'INSERT INTO Books (title, author, isbn, category, quantity, available_quantity) VALUES (?, ?, ?, ?, ?, ?)',
            [title, author, isbn, category, quantity, quantity]
        );
        res.status(201).json({ message: 'Book added successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
});

router.put('/:id', requireAuth, requireAdmin, async (req, res) => {
    const { id } = req.params;
    const { title, author, isbn, category, quantity } = req.body;
    try {
        await pool.query(
            'UPDATE Books SET title = ?, author = ?, isbn = ?, category = ?, quantity = ?, available_quantity = ? WHERE id = ?',
            [title, author, isbn, category, quantity, quantity, id]
        );
        res.json({ message: 'Book updated successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
});

router.delete('/:id', requireAuth, requireAdmin, async (req, res) => {
    const { id } = req.params;
    try {
        await pool.query('DELETE FROM Books WHERE id = ?', [id]);
        res.json({ message: 'Book deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
});

module.exports = router;