const express = require('express');
const pool = require('../config/db');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const router = express.Router();

router.post('/borrow', requireAuth, async (req, res) => {
    const { book_id } = req.body;
    const user_id = req.session.user.id;
    try {
        const [books] = await pool.query('SELECT available_quantity FROM Books WHERE id = ?', [book_id]);
        if (books[0].available_quantity <= 0) {
            return res.status(400).json({ message: 'Book not available' });
        }
        await pool.query(
            'INSERT INTO Borrowings (user_id, book_id, status) VALUES (?, ?, ?)',
            [user_id, book_id, 'pending']
        );
        res.status(201).json({ message: 'Borrow request submitted' });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
});

router.post('/approve/:id', requireAuth, requireAdmin, async (req, res) => {
    const { id } = req.params;
    try {
        const [borrowings] = await pool.query('SELECT * FROM Borrowings WHERE id = ?', [id]);
        const borrowing = borrowings[0];
        if (!borrowing || borrowing.status !== 'pending') {
            return res.status(400).json({ message: 'Invalid or non-pending request' });
        }
        const [books] = await pool.query('SELECT available_quantity FROM Books WHERE id = ?', [borrowing.book_id]);
        if (books[0].available_quantity <= 0) {
            return res.status(400).json({ message: 'Book no longer available' });
        }
        const borrow_date = new Date();
        const return_date = new Date(borrow_date.setDate(borrow_date.getDate() + 14)); // 2 weeks loan
        await pool.query(
            'UPDATE Borrowings SET status = ?, borrow_date = ?, return_date = ? WHERE id = ?',
            ['approved', borrow_date, return_date, id]
        );
        await pool.query('UPDATE Books SET available_quantity = available_quantity - 1 WHERE id = ?', [borrowing.book_id]);
        res.json({ message: 'Borrow request approved' });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
});

router.post('/reject/:id', requireAuth, requireAdmin, async (req, res) => {
    const { id } = req.params;
    try {
        const [borrowings] = await pool.query('SELECT * FROM Borrowings WHERE id = ?', [id]);
        const borrowing = borrowings[0];
        if (!borrowing || borrowing.status !== 'pending') {
            return res.status(400).json({ message: 'Invalid or non-pending request' });
        }
        await pool.query('UPDATE Borrowings SET status = ? WHERE id = ?', ['rejected', id]);
        res.json({ message: 'Borrow request rejected' });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
});

router.post('/return/:id', requireAuth, async (req, res) => {
    const { id } = req.params;
    const user_id = req.session.user.id;
    try {
        const [borrowings] = await pool.query('SELECT * FROM Borrowings WHERE id = ? AND user_id = ?', [id, user_id]);
        const borrowing = borrowings[0];
        if (!borrowing || borrowing.status !== 'approved') {
            return res.status(400).json({ message: 'Invalid or non-approved borrowing' });
        }
        await pool.query('UPDATE Borrowings SET status = ? WHERE id = ?', ['returned', id]);
        res.json({ message: 'Return request submitted' });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
});

router.post('/process-return/:id', requireAuth, requireAdmin, async (req, res) => {
    const { id } = req.params;
    try {
        const [borrowings] = await pool.query('SELECT * FROM Borrowings WHERE id = ?', [id]);
        const borrowing = borrowings[0];
        if (!borrowing || borrowing.status !== 'returned') {
            return res.status(400).json({ message: 'Invalid or non-returned request' });
        }
        const actual_return_date = new Date();
        let fine = 0;
        if (actual_return_date > new Date(borrowing.return_date)) {
            const daysLate = Math.ceil((actual_return_date - new Date(borrowing.return_date)) / (1000 * 60 * 60 * 24));
            fine = daysLate * 1.00; // $1 per day late
        }
        await pool.query(
            'UPDATE Borrowings SET actual_return_date = ?, fine = ? WHERE id = ?',
            [actual_return_date, fine, id]
        );
        await pool.query('UPDATE Books SET available_quantity = available_quantity + 1 WHERE id = ?', [borrowing.book_id]);
        res.json({ message: 'Book return processed', fine });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
});

router.get('/requests', requireAuth, requireAdmin, async (req, res) => {
    try {
        const [requests] = await pool.query(
            'SELECT b.*, u.name, k.title FROM Borrowings b JOIN Users u ON b.user_id = u.id JOIN Books k ON b.book_id = k.id WHERE b.status IN (?, ?)',
            ['pending', 'returned']
        );
        res.json(requests);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
});

router.get('/history', requireAuth, async (req, res) => {
    const user_id = req.session.user.id;
    try {
        const [borrowings] = await pool.query(
            'SELECT b.*, k.title FROM Borrowings b JOIN Books k ON b.book_id = k.id WHERE b.user_id = ?',
            [user_id]
        );
        res.json(borrowings);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
});

router.get('/report', requireAuth, requireAdmin, async (req, res) => {
    try {
        const [borrowed] = await pool.query(
            'SELECT b.*, u.name, k.title FROM Borrowings b JOIN Users u ON b.user_id = u.id JOIN Books k ON b.book_id = k.id WHERE b.status = ?',
            ['approved']
        );
        const [overdue] = await pool.query(
            'SELECT b.*, u.name, k.title FROM Borrowings b JOIN Users u ON b.user_id = u.id JOIN Books k ON b.book_id = k.id WHERE b.status = ? AND b.return_date < CURDATE() AND b.actual_return_date IS NULL',
            ['approved']
        );
        const [inventory] = await pool.query('SELECT * FROM Books');
        res.json({ borrowed, overdue, inventory });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
});

module.exports = router;