import { useState, useEffect } from 'react';
import axios from 'axios';

function Borrow() {
    const [books, setBooks] = useState([]);
    const [search, setSearch] = useState('');

    useEffect(() => {
        fetchBooks();
    }, []);

    const fetchBooks = async () => {
        const res = await axios.get('http://localhost:5000/api/books', { withCredentials: true });
        setBooks(res.data);
    };

    const handleBorrow = async (bookId) => {
        try {
            await axios.post(
                'http://localhost:5000/api/borrowings/borrow',
                { book_id: bookId },
                { withCredentials: true }
            );
            alert('Borrow request submitted. Await admin approval.');
        } catch (err) {
            alert(err.response?.data?.message || 'Failed to submit borrow request');
        }
    };

    const filteredBooks = books.filter((book) =>
        book.title.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <div>
            <h2 className="text-2xl font-bold mb-4">Borrow Books</h2>
            <input
                type="text"
                placeholder="Search books..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full p-2 border rounded mb-4"
            />
            <table className="w-full bg-white rounded shadow">
                <thead>
                    <tr className="bg-gray-200">
                        <th className="p-2">Title</th>
                        <th className="p-2">Author</th>
                        <th className="p-2">Available</th>
                        <th className="p-2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredBooks.map((book) => (
                        <tr key={book.id}>
                            <td className="p-2">{book.title}</td>
                            <td className="p-2">{book.author}</td>
                            <td className="p-2">{book.available_quantity}</td>
                            <td className="p-2">
                                <button
                                    onClick={() => handleBorrow(book.id)}
                                    className="bg-green-600 text-white p-2 rounded hover:bg-green-700"
                                    disabled={book.available_quantity === 0}
                                >
                                    Request Borrow
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default Borrow;