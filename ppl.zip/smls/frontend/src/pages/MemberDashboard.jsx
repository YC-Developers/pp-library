import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

function MemberDashboard() {
    const [books, setBooks] = useState([]);
    const [borrowings, setBorrowings] = useState([]);
    const [search, setSearch] = useState('');

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        try {
            const [booksRes, borrowingsRes] = await Promise.all([
                axios.get('http://localhost:5000/api/books', { withCredentials: true }),
                axios.get('http://localhost:5000/api/borrowings/history', { withCredentials: true }),
            ]);
            setBooks(booksRes.data);
            setBorrowings(borrowingsRes.data.filter((b) => b.status === 'approved' || b.status === 'returned'));
        } catch (error) {
            console.error('Failed to fetch data:', error);
        }
    };

    const filteredBooks = books.filter((book) =>
        book.title.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <div>
            <h2 className="text-2xl font-bold mb-6">Member Dashboard</h2>
            <div className="mb-6">
                <input
                    type="text"
                    placeholder="Search books..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="w-full p-2 border rounded"
                />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                    <h3 className="text-xl font-semibold mb-4">Available Books</h3>
                    <table className="w-full bg-white rounded shadow">
                        <thead>
                            <tr className="bg-gray-200">
                                <th className="p-2">Title</th>
                                <th className="p-2">Author</th>
                                <th className="p-2">Available</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredBooks.slice(0, 5).map((book) => (
                                <tr key={book.id}>
                                    <td className="p-2">{book.title}</td>
                                    <td className="p-2">{book.author}</td>
                                    <td className="p-2">{book.available_quantity}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    <Link to="/borrow" className="mt-4 inline-block bg-green-600 text-white p-2 rounded hover:bg-green-700">
                        Borrow a Book
                    </Link>
                </div>
                <div>
                    <h3 className="text-xl font-semibold mb-4">Your Borrowings</h3>
                    <table className="w-full bg-white rounded shadow">
                        <thead>
                            <tr className="bg-gray-200">
                                <th className="p-2">Book Title</th>
                                <th className="p-2">Status</th>
                                <th className="p-2">Due Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            {borrowings.slice(0, 5).map((borrowing) => (
                                <tr key={borrowing.id}>
                                    <td className="p-2">{borrowing.title}</td>
                                    <td className="p-2">{borrowing.status}</td>
                                    <td className="p-2">
                                        {borrowing.return_date ? new Date(borrowing.return_date).toLocaleDateString() : 'N/A'}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    <Link to="/history" className="mt-4 inline-block bg-blue-600 text-white p-2 rounded hover:bg-blue-700">
                        View Borrowing History
                    </Link>
                </div>
            </div>
        </div>
    );
}

export default MemberDashboard;