import { useState, useEffect } from 'react';
import axios from 'axios';

function Requests() {
    const [requests, setRequests] = useState([]);

    useEffect(() => {
        fetchRequests();
    }, []);

    const fetchRequests = async () => {
        const res = await axios.get('http://localhost:5000/api/borrowings/requests', { withCredentials: true });
        setRequests(res.data);
    };

    const handleApprove = async (id) => {
        try {
            await axios.post(`http://localhost:5000/api/borrowings/approve/${id}`, {}, { withCredentials: true });
            fetchRequests();
        } catch (err) {
            alert(err.response?.data?.message || 'Failed to approve request');
        }
    };

    const handleReject = async (id) => {
        try {
            await axios.post(`http://localhost:5000/api/borrowings/reject/${id}`, {}, { withCredentials: true });
            fetchRequests();
        } catch (err) {
            alert(err.response?.data?.message || 'Failed to reject request');
        }
    };

    const handleProcessReturn = async (id) => {
        try {
            const res = await axios.post(`http://localhost:5000/api/borrowings/process-return/${id}`, {}, { withCredentials: true });
            alert(`Return processed. Fine: $${res.data.fine}`);
            fetchRequests();
        } catch (err) {
            alert(err.response?.data?.message || 'Failed to process return');
        }
    };

    return (
        <div>
            <h2 className="text-2xl font-bold mb-4">Manage Requests</h2>
            <table className="w-full bg-white rounded shadow">
                <thead>
                    <tr className="bg-gray-200">
                        <th className="p-2">User</th>
                        <th className="p-2">Book Title</th>
                        <th className="p-2">Status</th>
                        <th className="p-2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {requests.map((req) => (
                        <tr key={req.id}>
                            <td className="p-2">{req.name}</td>
                            <td className="p-2">{req.title}</td>
                            <td className="p-2">{req.status}</td>
                            <td className="p-2">
                                {req.status === 'pending' && (
                                    <>
                                        <button
                                            onClick={() => handleApprove(req.id)}
                                            className="bg-green-600 text-white p-2 rounded hover:bg-green-700 mr-2"
                                        >
                                            Approve
                                        </button>
                                        <button
                                            onClick={() => handleReject(req.id)}
                                            className="bg-red-600 text-white p-2 rounded hover:bg-red-700"
                                        >
                                            Reject
                                        </button>
                                    </>
                                )}
                                {req.status === 'returned' && (
                                    <button
                                        onClick={() => handleProcessReturn(req.id)}
                                        className="bg-blue-600 text-white p-2 rounded hover:bg-blue-700"
                                    >
                                        Process Return
                                    </button>
                                )}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default Requests;