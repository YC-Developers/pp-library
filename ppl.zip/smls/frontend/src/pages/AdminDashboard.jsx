import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { Book, Clock, Users, AlertCircle, ArrowRight, Calendar } from 'lucide-react';

function AdminDashboard() {
    const [stats, setStats] = useState({ 
        books: 0, 
        pendingRequests: 0, 
        recentBorrowings: [],
        isLoading: true
    });

    useEffect(() => {
        fetchStats();
    }, []);

    const fetchStats = async () => {
        try {
            const [booksRes, requestsRes, reportRes] = await Promise.all([
                axios.get('http://localhost:5000/api/books', { withCredentials: true }),
                axios.get('http://localhost:5000/api/borrowings/requests', { withCredentials: true }),
                axios.get('http://localhost:5000/api/borrowings/report', { withCredentials: true }),
            ]);
            setStats({
                books: booksRes.data.length,
                pendingRequests: requestsRes.data.length,
                recentBorrowings: reportRes.data.borrowed.slice(0, 5),
                isLoading: false
            });
        } catch (error) {
            console.error('Failed to fetch stats:', error);
            setStats(prev => ({...prev, isLoading: false}));
        }
    };

    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-8">
                <h2 className="text-3xl font-bold text-green-800">Admin Dashboard</h2>
                <Link 
                    to="/report" 
                    className="flex items-center gap-2 bg-gradient-to-r from-green-600 to-green-500 text-white px-4 py-2 rounded-lg hover:from-green-700 hover:to-green-600 transition"
                >
                    View Full Report <ArrowRight className="w-4 h-4" />
                </Link>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-white p-6 rounded-xl shadow-sm border border-green-50 hover:shadow-md transition">
                    <div className="flex items-center gap-4">
                        <div className="p-3 rounded-full bg-green-100 text-green-600">
                            <Book className="w-6 h-6" />
                        </div>
                        <div>
                            <h3 className="text-lg font-medium text-gray-600">Total Books</h3>
                            <p className="text-3xl font-bold text-green-800">
                                {stats.isLoading ? '--' : stats.books}
                            </p>
                        </div>
                    </div>
                    <Link 
                        to="/books" 
                        className="mt-4 inline-flex items-center text-sm font-medium text-amber-600 hover:text-amber-500 transition"
                    >
                        Manage Books <ArrowRight className="w-4 h-4 ml-1" />
                    </Link>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border border-green-50 hover:shadow-md transition">
                    <div className="flex items-center gap-4">
                        <div className="p-3 rounded-full bg-amber-100 text-amber-600">
                            <Clock className="w-6 h-6" />
                        </div>
                        <div>
                            <h3 className="text-lg font-medium text-gray-600">Pending Requests</h3>
                            <p className="text-3xl font-bold text-amber-800">
                                {stats.isLoading ? '--' : stats.pendingRequests}
                            </p>
                        </div>
                    </div>
                    <Link 
                        to="/requests" 
                        className="mt-4 inline-flex items-center text-sm font-medium text-amber-600 hover:text-amber-500 transition"
                    >
                        View Requests <ArrowRight className="w-4 h-4 ml-1" />
                    </Link>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border border-green-50 hover:shadow-md transition">
                    <div className="flex items-center gap-4">
                        <div className="p-3 rounded-full bg-green-100 text-green-600">
                            <Users className="w-6 h-6" />
                        </div>
                        <div>
                            <h3 className="text-lg font-medium text-gray-600">Users</h3>
                            <p className="text-3xl font-bold text-green-800">--</p>
                        </div>
                    </div>
                    <Link 
                        to="/users" 
                        className="mt-4 inline-flex items-center text-sm font-medium text-amber-600 hover:text-amber-500 transition"
                    >
                        Manage Users <ArrowRight className="w-4 h-4 ml-1" />
                    </Link>
                </div>
            </div>

            {/* Recent Borrowings */}
            <div className="bg-white rounded-xl shadow-sm border border-green-50 overflow-hidden">
                <div className="p-6 border-b border-green-100">
                    <h3 className="text-xl font-semibold text-green-800">Recent Borrowings</h3>
                </div>
                
                {stats.isLoading ? (
                    <div className="p-6 text-center text-gray-500">Loading...</div>
                ) : stats.recentBorrowings.length === 0 ? (
                    <div className="p-6 flex items-center gap-2 text-amber-600">
                        <AlertCircle className="w-5 h-5" />
                        <span>No recent borrowings found</span>
                    </div>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead className="bg-green-50">
                                <tr>
                                    <th className="p-4 text-left text-sm font-medium text-green-800">User</th>
                                    <th className="p-4 text-left text-sm font-medium text-green-800">Book Title</th>
                                    <th className="p-4 text-left text-sm font-medium text-green-800">Borrow Date</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-green-100">
                                {stats.recentBorrowings.map((borrowing) => (
                                    <tr key={borrowing.id} className="hover:bg-green-50 transition">
                                        <td className="p-4 text-gray-700">{borrowing.name}</td>
                                        <td className="p-4 text-gray-700">{borrowing.title}</td>
                                        <td className="p-4 text-gray-700">
                                            <div className="flex items-center gap-2">
                                                <Calendar className="w-4 h-4 text-amber-600" />
                                                {new Date(borrowing.borrow_date).toLocaleDateString()}
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </div>
    );
}

export default AdminDashboard;