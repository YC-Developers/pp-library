import { useState, useEffect } from 'react';
import axios from 'axios';

function History() {
    const [history, setHistory] = useState([]);

    useEffect(() => {
        fetchHistory();
    }, []);

    const fetchHistory = async () => {
        const res = await axios.get('http://localhost:5000/api/borrowings/history', { withCredentials: true });
        setHistory(res.data);
    };

    const handleReturn = async (id) => {
        try {
            await axios.post(`http://localhost:5000/api/borrowings/return/${id}`, {}, { withCredentials: true });
            alert('Return request submitted. Await admin processing.');
            fetchHistory();
        } catch (err) {
            alert(err.response?.data?.message || 'Failed to submit return request');
        }
    };

    return (
        <div>
            <h2 className="text-2xl font-bold mb-4">Borrowing History</h2>
            <table className="w-full bg-white rounded shadow">
                <thead>
                    <tr className="bg-gray-200">
                        <th className="p-2">Book Title</th>
                        <th className="p-2">Borrow Date</th>
                        <th className="p-2">Return Date</th>
                        <th className="p-2">Status</th>
                        <th className="p-2">Fine</th>
                        <th className="p-2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {history.map((item) => (
                        <tr key={item.id}>
                            <td className="p-2">{item.title}</td>
                            <td className="p-2">
                                {item.borrow_date ? new Date(item.borrow_date).toLocaleDateString() : 'N/A'}
                            </td>
                            <td className="p-2">
                                {item.return_date ? new Date(item.return_date).toLocaleDateString() : 'N/A'}
                            </td>
                            <td className="p-2">{item.status}</td>
                            <td className="p-2">${item.fine}</td>
                            <td className="p-2">
                                {item.status === 'approved' && (
                                    <button
                                        onClick={() => handleReturn(item.id)}
                                        className="bg-yellow-600 text-white p-2 rounded hover:bg-yellow-700"
                                    >
                                        Request Return
                                    </button>
                                )}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default History;