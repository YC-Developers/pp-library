import { useState, useEffect } from 'react';
import axios from 'axios';

function Report() {
    const [report, setReport] = useState({ borrowed: [], overdue: [], inventory: [] });

    useEffect(() => {
        fetchReport();
    }, []);

    const fetchReport = async () => {
        const res = await axios.get('http://localhost:5000/api/borrowings/report', { withCredentials: true });
        setReport(res.data);
    };

    return (
        <div>
            <h2 className="text-2xl font-bold mb-4">Library Reports</h2>
            <h3 className="text-xl font-semibold mb-2">Currently Borrowed Books</h3>
            <table className="w-full bg-white rounded shadow mb-6">
                <thead>
                    <tr className="bg-gray-200">
                        <th className="p-2">User</th>
                        <th className="p-2">Book Title</th>
                        <th className="p-2">Borrow Date</th>
                        <th className="p-2">Return Date</th>
                    </tr>
                </thead>
                <tbody>
                    {report.borrowed.map((item) => (
                        <tr key={item.id}>
                            <td className="p-2">{item.name}</td>
                            <td className="p-2">{item.title}</td>
                            <td className="p-2">{new Date(item.borrow_date).toLocaleDateString()}</td>
                            <td className="p-2">{new Date(item.return_date).toLocaleDateString()}</td>
                        </tr>
                    ))}
                </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">Overdue Books</h3>
            <table className="w-full bg-white rounded shadow mb-6">
                <thead>
                    <tr className="bg-gray-200">
                        <th className="p-2">User</th>
                        <th className="p-2">Book Title</th>
                        <th className="p-2">Borrow Date</th>
                        <th className="p-2">Return Date</th>
                    </tr>
                </thead>
                <tbody>
                    {report.overdue.map((item) => (
                        <tr key={item.id}>
                            <td className="p-2">{item.name}</td>
                            <td className="p-2">{item.title}</td>
                            <td className="p-2">{new Date(item.borrow_date).toLocaleDateString()}</td>
                            <td className="p-2">{new Date(item.return_date).toLocaleDateString()}</td>
                        </tr>
                    ))}
                </tbody>
            </table>

            <h3 className="text-xl font-semibold mb-2">Inventory</h3>
            <table className="w-full bg-white rounded shadow">
                <thead>
                    <tr className="bg-gray-200">
                        <th className="p-2">Title</th>
                        <th className="p-2">Author</th>
                        <th className="p-2">Quantity</th>
                        <th className="p-2">Available</th>
                    </tr>
                </thead>
                <tbody>
                    {report.inventory.map((book) => (
                        <tr key={book.id}>
                            <td className="p-2">{book.title}</td>
                            <td className="p-2">{book.author}</td>
                            <td className="p-2">{book.quantity}</td>
                            <td className="p-2">{book.available_quantity}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default Report;