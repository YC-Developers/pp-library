import { LogOut, Menu, Sun, Moon } from 'lucide-react';
import axios from 'axios';
import { useState } from 'react';

function Header({ onToggleSidebar }) {
    const [darkMode, setDarkMode] = useState(false);
    const [isLoggingOut, setIsLoggingOut] = useState(false);

    const handleLogout = async () => {
        setIsLoggingOut(true);
        try {
            await axios.post('http://localhost:5000/api/auth/logout', {}, { withCredentials: true });
            window.location.href = '/login';
        } catch (error) {
            console.error('Logout failed:', error);
            setIsLoggingOut(false);
        }
    };

    return (
        <header className="bg-white shadow-sm border-b border-green-100 p-4 flex justify-between items-center sticky top-0 z-10">
            <div className="flex items-center gap-4">
                <button 
                    onClick={onToggleSidebar}
                    className="p-2 rounded-lg text-green-700 hover:bg-green-50 md:hidden"
                >
                    <Menu className="w-5 h-5" />
                </button>
                <h2 className="text-xl font-bold text-green-800 hidden sm:block">
                    Smart Library Management System
                </h2>
                <span className="text-sm font-medium bg-green-100 text-green-800 px-3 py-1 rounded-full sm:hidden">
                    SLMS
                </span>
            </div>

            <div className="flex items-center gap-4">
                <button 
                    onClick={() => setDarkMode(!darkMode)}
                    className="p-2 rounded-full text-amber-600 hover:bg-amber-50 transition-colors"
                    aria-label="Toggle dark mode"
                >
                    {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
                </button>

                <button
                    onClick={handleLogout}
                    disabled={isLoggingOut}
                    className="flex items-center gap-2 px-4 py-2 rounded-lg text-amber-700 hover:bg-amber-50 transition-colors disabled:opacity-70"
                >
                    {isLoggingOut ? (
                        <span className="animate-pulse">Logging out...</span>
                    ) : (
                        <>
                            <LogOut className="w-5 h-5" />
                            <span className="hidden sm:inline">Logout</span>
                        </>
                    )}
                </button>
            </div>
        </header>
    );
}

export default Header;