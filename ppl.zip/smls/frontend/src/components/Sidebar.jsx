import { NavLink } from 'react-router-dom';
import { Book, Users, BookOpen, History, FileText, UserPlus, ClipboardList, Home, LogOut } from 'lucide-react';
import { useEffect, useState } from 'react';
import axios from 'axios';

function Sidebar() {
    const [user, setUser] = useState(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        axios
            .get('http://localhost:5000/api/auth/session', { withCredentials: true })
            .then((res) => {
                setUser(res.data.user);
                setIsLoading(false);
            })
            .catch(() => {
                setUser(null);
                setIsLoading(false);
            });
    }, []);

    const navItems = [
        { to: '/admin-dashboard', label: 'Admin Dashboard', icon: Home, adminOnly: true },
        { to: '/member-dashboard', label: 'Member Dashboard', icon: Home, memberOnly: true },
        { to: '/books', label: 'Books', icon: Book },
        { to: '/users', label: 'Users', icon: Users, adminOnly: true },
        { to: '/register', label: 'Register', icon: UserPlus, adminOnly: true },
        { to: '/requests', label: 'Requests', icon: ClipboardList, adminOnly: true },
        { to: '/borrow', label: 'Borrow', icon: BookOpen },
        { to: '/history', label: 'History', icon: History },
        { to: '/report', label: 'Reports', icon: FileText, adminOnly: true },
    ];

    const handleLogout = async () => {
        try {
            await axios.post('http://localhost:5000/api/auth/logout', {}, { withCredentials: true });
            window.location.reload();
        } catch (error) {
            console.error('Logout failed:', error);
        }
    };

    return (
        <div className="w-64 bg-gradient-to-b from-green-800 to-green-700 text-white h-[120vh] flex flex-col p-5 shadow-lg">
            {/* Header */}
            <div className="mb-8">
                <h1 className="text-2xl font-bold text-white mb-1">SLMS</h1>
                <p className="text-sm text-green-200">Library Management System</p>
            </div>

            {/* User Profile */}
            {!isLoading && user && (
                <div className="flex items-center gap-3 mb-6 p-3 bg-green-900 bg-opacity-30 rounded-lg">
                    <div className="w-10 h-10 rounded-full bg-amber-500 flex items-center justify-center text-white font-bold">
                        {user.name}
                    </div>
                    <div>
                        <p className="font-medium">{user.name}</p>
                        <p className="text-xs text-green-200 capitalize">{user.role}</p>
                    </div>
                </div>
            )}

            {/* Navigation */}
            <nav className="flex-1 space-y-1">
                {navItems.map((item) => (
                    (!item.adminOnly || (user && user.role === 'admin')) &&
                    (!item.memberOnly || (user && user.role === 'member')) && (
                        <NavLink
                            key={item.to}
                            to={item.to}
                            className={({ isActive }) =>
                                `flex items-center p-3 rounded-lg transition-all ${isActive 
                                    ? 'bg-green-600 shadow-md' 
                                    : 'hover:bg-green-700 hover:bg-opacity-50'}`
                            }
                        >
                            <item.icon className="w-5 h-5 mr-3" />
                            <span>{item.label}</span>
                        </NavLink>
                    )
                ))}
            </nav>

            {/* Footer/Logout */}
            <div className="mt-auto pt-4 border-t border-green-700">
                {user && (
                    <button
                        onClick={handleLogout}
                        className="flex items-center w-full p-3 rounded-lg text-green-100 hover:bg-green-700 hover:text-white transition-colors"
                    >
                        <LogOut className="w-5 h-5 mr-3" />
                        <span>Logout</span>
                    </button>
                )}
            </div>
        </div>
    );
}

export default Sidebar;