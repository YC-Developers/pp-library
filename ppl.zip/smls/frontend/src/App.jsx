import { Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Login from './pages/Login';
import Books from './pages/Books';
import Users from './pages/Users';
import Borrow from './pages/Borrow';
import History from './pages/History';
import Report from './pages/Report';
import Register from './pages/Register';
import Requests from './pages/Requests';
import AdminDashboard from './pages/AdminDashboard';
import MemberDashboard from './pages/MemberDashboard';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
    return (
        <div className="flex h-screen">
            <Sidebar />
            <div className="flex-1 flex flex-col">
                <Header />
                <main className="flex-1 p-6 bg-gray-100 overflow-auto">
                    <Routes>
                        <Route path="/login" element={<Login />} />
                        <Route
                            path="/admin-dashboard"
                            element={
                                <ProtectedRoute adminOnly>
                                    <AdminDashboard />
                                </ProtectedRoute>
                            }
                        />
                        <Route
                            path="/member-dashboard"
                            element={
                                <ProtectedRoute>
                                    <MemberDashboard />
                                </ProtectedRoute>
                            }
                        />
                        <Route
                            path="/books"
                            element={
                                <ProtectedRoute>
                                    <Books />
                                </ProtectedRoute>
                            }
                        />
                        <Route
                            path="/users"
                            element={
                                <ProtectedRoute adminOnly>
                                    <Users />
                                </ProtectedRoute>
                            }
                        />
                        <Route
                            path="/register"
                            element={
                                <ProtectedRoute adminOnly>
                                    <Register />
                                </ProtectedRoute>
                            }
                        />
                        <Route
                            path="/requests"
                            element={
                                <ProtectedRoute adminOnly>
                                    <Requests />
                                </ProtectedRoute>
                            }
                        />
                        <Route
                            path="/borrow"
                            element={
                                <ProtectedRoute>
                                    <Borrow />
                                </ProtectedRoute>
                            }
                        />
                        <Route
                            path="/history"
                            element={
                                <ProtectedRoute>
                                    <History />
                                </ProtectedRoute>
                            }
                        />
                        <Route
                            path="/report"
                            element={
                                <ProtectedRoute adminOnly>
                                    <Report />
                                </ProtectedRoute>
                            }
                        />
                    </Routes>
                </main>
            </div>
        </div>
    );
}

export default App;